import {readFile,writeFile} from 'node:fs/promises';
const base='/tmp/solar-remediation-completion-20261030/startup-diagnosis';
const label=process.argv[2]??'continuous-dev';
const report=JSON.parse(await readFile(`${base}/${label}.json`,'utf8'));
const result={mode:report.mode,firstSubmit:report.firstFullSceneSubmittedAt,fenceObserved:report.fullSceneFenceObservedAt,gapMs:report.fullSceneFenceObservedAt-report.firstFullSceneSubmittedAt,gpuMs:report.firstRenderGpuElapsedMs,gpuSupported:report.gpuTimerSupported,gpuDisjoint:report.gpuDisjoint,graphics:report.graphics,renders:report.renders,glSlowCalls:report.glSlowCalls,fencePolls:report.fencePolls,longTasks:report.longTasks,largestHeartbeatGaps:[...report.heartbeat].sort((a,b)=>b.lag-a.lag).slice(0,10),inputs:report.inputs,inputDispatch:report.inputDispatch,hud:report.hud,raf:report.raf,errors:report.errors};
if(report.profiling){
 const trace=JSON.parse(await readFile(`${base}/${label}.trace.json`,'utf8'));
 const marks=trace.traceEvents.filter(event=>event.name?.startsWith('startup-diag:'));
 result.traceMarks=marks.map(({name,ts,pid,tid,ph})=>({name,ts,pid,tid,ph}));
 const mark=marks.find(e=>e.name==='startup-diag:render-1-return');
 const fence=marks.find(e=>e.name==='startup-diag:fence-observed');
 const profile=JSON.parse(await readFile(`${base}/${label}.cpuprofile`,'utf8'));
 const nodes=new Map(profile.nodes.map(n=>[n.id,n]));const parents=new Map();
 for(const n of profile.nodes)for(const id of n.children??[])parents.set(id,n.id);
 const buckets=new Map(), inclusive=new Map();let at=profile.startTime,totalMs=0,selectedSamples=0;
 const aligned=Boolean(mark&&fence&&mark.ts>=profile.startTime&&fence.ts<=profile.endTime);
 result.profileClock={start:profile.startTime,end:profile.endTime,markTs:mark?.ts,fenceTs:fence?.ts,aligned};
 function add(map,node,ms){const f=node.callFrame;const key=`${f.functionName}|${f.url}|${f.lineNumber}`;const b=map.get(key)??{function:f.functionName||'(anonymous)',url:f.url,line:f.lineNumber+1,ms:0};b.ms+=ms;map.set(key,b);}
 const timestamped=[];
 for(let index=0;index<(profile.samples??[]).length;index++){
   at+=profile.timeDeltas[index]??1000;timestamped.push({at,id:profile.samples[index]});
 }
 timestamped.sort((a,b)=>a.at-b.at);
 for(let index=0;index<timestamped.length;index++){
  const sample=timestamped[index],end=timestamped[index+1]?.at??profile.endTime;
  const ms=aligned?Math.max(0,Math.min(end,fence.ts)-Math.max(sample.at,mark.ts))/1000:Math.max(0,end-sample.at)/1000;
  if(ms>0){totalMs+=ms;selectedSamples++;let id=sample.id;const node=nodes.get(id);if(node)add(buckets,node,ms);const seen=new Set();while(id&&!seen.has(id)){seen.add(id);const n=nodes.get(id);if(n)add(inclusive,n,ms);id=parents.get(id);}}
 }

 result.cpuProfile={negativeDeltaCount:profile.timeDeltas.filter(delta=>delta<0).length,sampleOrdering:'sort cumulative timestamps before assigning non-overlapping duration weights',window:aligned?'first full render return to fence observation':'whole profile (clock alignment unavailable)',totalMs,selectedSamples,self:[...buckets.values()].sort((a,b)=>b.ms-a.ms).slice(0,30),inclusive:[...inclusive.values()].sort((a,b)=>b.ms-a.ms).slice(0,35)};
 const pid=mark?.pid,tid=mark?.tid;
 result.traceLongEvents=trace.traceEvents.filter(e=>e.ph==='X'&&e.pid===pid&&e.tid===tid&&e.dur>10000&&(!aligned||(e.ts<fence.ts&&e.ts+e.dur>mark.ts))).sort((a,b)=>b.dur-a.dur).slice(0,35).map(({name,ts,dur,cat,args})=>({name,ts,dur,cat,data:args?.data}));
}
await writeFile(`${base}/${label}.summary.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({firstSubmit:result.firstSubmit,fence:result.fenceObserved,gap:result.gapMs,gpu:result.gpuMs,gpuSupported:result.gpuSupported,graphics:result.graphics,renders:result.renders,cpu:result.cpuProfile?.self.slice(0,12),slowGL:result.glSlowCalls,longTasks:result.longTasks,polls:result.fencePolls,inputs:result.inputs,inputDispatch:result.inputDispatch,hud:result.hud},null,2));
