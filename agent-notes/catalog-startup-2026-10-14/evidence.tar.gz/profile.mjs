import { chromium } from '@playwright/test';
import { writeFile } from 'node:fs/promises';
import { loadavg } from 'node:os';
const origin='http://127.0.0.1:5186';
const directory='artifacts/solar-catalog-startup';
const browser=await chromium.launch({headless:true,executablePath:'/home/nomad/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const results=[];
try {
 for(const mode of ['isolated-1','isolated-2','isolated-3','full-app']) {
  const context=await browser.newContext({viewport:{width:1280,height:900}});
  const page=await context.newPage();
  const consoleMessages=[];
  page.on('console',message=>{if(/phase-1/.test(message.text()))consoleMessages.push({type:message.type(),text:message.text()});});
  page.on('pageerror',error=>consoleMessages.push({type:'pageerror',text:error.message}));
  await page.addInitScript(()=>{
   const capture={events:[],longTasks:[],gl:{},loadAt:performance.now()};
   window.__catalogProfile=capture;
   new PerformanceObserver(list=>{for(const item of list.getEntries())capture.longTasks.push({start:item.startTime,duration:item.duration,name:item.name});}).observe({type:'longtask',buffered:true});
   const matches=url=>String(url).includes('asteroid_phase1_main_100000');
   const fetchOriginal=window.fetch;
   window.fetch=async function(input,init){
    const url=typeof input==='string'?input:input.url??String(input);
    if(!matches(url))return fetchOriginal.call(this,input,init);
    const start=performance.now();
    try{const response=await fetchOriginal.call(this,input,init);capture.events.push({stage:'fetch-headers',url,start,end:performance.now(),status:response.status});return response;}
    catch(error){capture.events.push({stage:'fetch-error',url,start,end:performance.now(),error:String(error)});throw error;}
   };
   for(const method of ['arrayBuffer','json']){
    const original=Response.prototype[method];
    Response.prototype[method]=async function(...args){
     if(!matches(this.url))return original.apply(this,args);
     const start=performance.now();
     try{const value=await original.apply(this,args);capture.events.push({stage:method,url:this.url,start,end:performance.now(),bytes:value.byteLength});return value;}
     catch(error){capture.events.push({stage:method+'-error',url:this.url,start,end:performance.now(),error:String(error)});throw error;}
    };
   }
   const digest=crypto.subtle.digest.bind(crypto.subtle);
   crypto.subtle.digest=async function(algorithm,data){const start=performance.now();const result=await digest(algorithm,data);capture.events.push({stage:'digest',algorithm,start,end:performance.now(),bytes:data.byteLength});return result;};
   for(const Constructor of [window.WebGLRenderingContext,window.WebGL2RenderingContext]){
    if(!Constructor)continue;
    for(const method of ['compileShader','linkProgram','getProgramParameter','getShaderParameter','drawElements','drawArrays','drawElementsInstanced','drawArraysInstanced']){
     const original=Constructor.prototype[method];if(typeof original!=='function')continue;
     Constructor.prototype[method]=function(...args){const start=performance.now();const result=original.apply(this,args);const duration=performance.now()-start;const stats=capture.gl[method]??={calls:0,totalMs:0,maxMs:0};stats.calls++;stats.totalMs+=duration;stats.maxMs=Math.max(stats.maxMs,duration);if(duration>50)capture.events.push({stage:'gl',method,start,end:start+duration,stack:new Error().stack});return result;};
    }
   }
  });
  const cdp=await context.newCDPSession(page);
  await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
  const loadStart=loadavg();
  let catalog;
  let profile;
  if(mode.startsWith('isolated')) {
   await page.route(origin+'/__catalog_profile__.html',route=>route.fulfill({contentType:'text/html',body:'<!doctype html><title>Isolated real catalog diagnostic</title>'}));
   await page.goto(origin+'/__catalog_profile__.html');
   catalog=await page.evaluate(async()=>{
    const {loadPhase1AsteroidCatalog}=await import('/src/sim/phase1AsteroidCatalog.ts');
    const start=performance.now();const result=await loadPhase1AsteroidCatalog({cache:false});
    return {start,end:performance.now(),accepted:result.accepted,loadedCount:result.loadedCount,sourceCount:result.sourceCount,loadMs:result.loadMs,acceptance:result.acceptance,checksum:result.checksumActual};
   });
  } else {
   await cdp.send('Profiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:1000});await cdp.send('Profiler.start');
   await page.goto(origin,{waitUntil:'domcontentloaded',timeout:45000});
   try{await page.waitForFunction(()=>['verified','error','fallback'].includes(document.getElementById('status-catalog')?.dataset.catalogState),null,{timeout:35000});}catch(error){consoleMessages.push({type:'wait-error',text:String(error)});}
   ({profile}=await cdp.send('Profiler.stop'));
   await writeFile(directory+'/full-app.cpuprofile',JSON.stringify(profile));
  }
  const capture=await page.evaluate(()=>({capture:window.__catalogProfile,resources:performance.getEntriesByType('resource').filter(r=>r.name.includes('asteroid_phase1_main_100000')).map(r=>r.toJSON()),chip:document.getElementById('status-catalog')?.outerHTML,renderer:(()=>{const gl=document.getElementById('space-canvas')?.getContext('webgl2');const d=gl?.getExtension('WEBGL_debug_renderer_info');return d?gl.getParameter(d.UNMASKED_RENDERER_WEBGL):null;})()}));
  if(capture.renderer&&!/swiftshader/i.test(capture.renderer))throw new Error('Unexpected non-software renderer: '+capture.renderer);
  const row={mode,loadStart,loadEnd:loadavg(),catalog,...capture,consoleMessages};
  results.push(row);
  await writeFile(directory+'/profile.json',JSON.stringify(results,null,2));
  console.log(JSON.stringify(row));
  await context.close();
 }
} finally {await browser.close();}
